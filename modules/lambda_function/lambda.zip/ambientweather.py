import json
import urllib.request
import boto3
import os
from datetime import datetime

API_KEY = os.environ.get("API_KEY")
APP_KEY = os.environ.get("APP_KEY")
BUCKET = os.environ.get("BUCKET")

def lambda_handler(event, context):
    url = f"https://api.ambientweather.net/v1/devices?apiKey={API_KEY}&applicationKey={APP_KEY}"

    with urllib.request.urlopen(url) as response:
        data = json.loads(response.read().decode())

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = f"ambient_data_{timestamp}.json"

    s3 = boto3.client("s3")
    s3.put_object(
        Bucket=BUCKET,
        Key=filename,
        Body=json.dumps(data),
        ContentType="application/json"
    )

    return {"statusCode": 200, "body": f"Archivo {filename} subido a S3"}